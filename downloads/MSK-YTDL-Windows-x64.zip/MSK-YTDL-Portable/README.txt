===================================================================
  MSK YTDL: Reliable YouTube Video & Audio Downloader
  Publisher: MSK Software Solutions
===================================================================

Thank you for choosing MSK YTDL by MSK Software Solutions!
This is a self-contained portable package. Zero Python or pip setup required!

QUICK START:
  1. Double-click "Start_MSK_YTDL.bat" or "MSK-YTDL.exe".
  2. Follow the numbered menu in the console window.
  3. Enter any YouTube video or playlist link.
  4. Files will be saved into your Windows "Downloads/YouTube" folder!

WINDOWS SMARTSCREEN / SECURITY NOTICE:
  MSK YTDL is 100% safe, open-source software with zero ads or tracking.
  If Windows displays "Windows protected your PC":
    1. Click "More info".
    2. Click "Run anyway".
  To permanently trust the publisher on this PC, right-click:
    "Install_MSK_Certificate.bat" -> "Run as administrator".

FFMPEG STATUS:
  Requires external FFmpeg
  FFmpeg enables merging high-resolution video streams (1080p, 1440p, 4K),
  converting audio to 320kbps MP3, and embedding album artwork.

COMMAND LINE USAGE:
  You can also run MSK YTDL from PowerShell or Command Prompt:
    .\MSK-YTDL.exe --url "https://www.youtube.com/watch?v=..." --mode video
    .\MSK-YTDL.exe --url "https://www.youtube.com/watch?v=..." --mode audio --audio-quality 320
    .\MSK-YTDL.exe --check

LEGAL & AUTHORIZED USE NOTICE:
  This tool is strictly intended for downloading videos you own,
  have explicit permission to save, or are authorized under applicable terms.
