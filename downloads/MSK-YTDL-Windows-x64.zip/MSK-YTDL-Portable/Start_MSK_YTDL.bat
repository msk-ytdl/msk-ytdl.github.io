@echo off
title MSK-YTDL - Reliable YouTube Downloader
cd /d "%~dp0"
start "" "MSK-YTDL.exe"
